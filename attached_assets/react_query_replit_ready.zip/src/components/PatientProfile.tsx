
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

const fetchPatient = async (patientId: number) => {
  const res = await axios.get(`/api/patients/${patientId}`);
  return res.data;
};

const PatientProfile = ({ patientId }: { patientId: number }) => {
  const queryClient = useQueryClient();

  const { data: patient, isLoading, isError } = useQuery(
    ['patient', patientId],
    () => fetchPatient(patientId)
  );

  const updatePatient = useMutation(
    (updatedData) => axios.patch(`/api/patients/${patientId}`, updatedData),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['patient', patientId]);
      }
    }
  );

  if (isLoading) return <p>Loading...</p>;
  if (isError) return <p>Error loading patient data</p>;

  const handleSave = async () => {
    const updates = { phone: '08123456789' }; // Example data
    await updatePatient.mutateAsync(updates);
  };

  return (
    <div className="p-4 border rounded shadow">
      <h1 className="text-xl font-bold">{patient.firstName} {patient.lastName}</h1>
      <p className="text-gray-600">Phone: {patient.phone}</p>
      <button
        onClick={handleSave}
        className="mt-2 bg-blue-500 text-white px-4 py-2 rounded"
      >
        Save Phone
      </button>
    </div>
  );
};

export default PatientProfile;
    