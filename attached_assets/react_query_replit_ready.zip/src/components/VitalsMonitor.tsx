
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

const VitalsMonitor = ({ patientId }: { patientId: number }) => {
  const queryClient = useQueryClient();

  const { data: vitals, isLoading, isError } = useQuery(['vitals', patientId], () =>
    axios.get(`/api/patients/${patientId}/vitals`).then(r => r.data)
  );

  const recordVitals = useMutation(
    (newVitals) => axios.post(`/api/patients/${patientId}/vitals`, newVitals),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['vitals', patientId]);
      }
    }
  );

  if (isLoading) return <p>Loading vitals...</p>;
  if (isError) return <p>Error loading vitals.</p>;

  const handleRecord = async () => {
    const newVitals = { bloodPressure: '120/80', heartRate: 72, temperature: 36.7 };
    await recordVitals.mutateAsync(newVitals);
  };

  return (
    <div className="p-4 border rounded shadow mt-4">
      <h2 className="text-lg font-bold">Vitals</h2>
      <ul className="mt-2">
        {vitals.map((v: any) => (
          <li key={v.id} className="border-b py-1">{v.bloodPressure} - {v.heartRate} bpm</li>
        ))}
      </ul>
      <button
        onClick={handleRecord}
        className="mt-2 bg-green-500 text-white px-4 py-2 rounded"
      >
        Record Vitals
      </button>
    </div>
  );
};

export default VitalsMonitor;
    